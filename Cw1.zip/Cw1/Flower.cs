﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cw1
{
    public class Flower
    {
        public int count { get; set; }

        public string name { get; set; }

        public Flower() {
            this.count = 0;
            this.name = "";
        }

    }
}
